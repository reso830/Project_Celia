# Handoff: Celia — Household Budget Tracker

## Overview
Celia is a household budget-tracking web app replacing a personal Excel workflow. Core jobs: fast transaction entry, categorizing spend into two-level "buckets" (group → sub-category), supporting multiple household members with individual and combined views, and visualizing income/expense/cash-flow trends. A future phase (not built yet) is forecasting.

## About the Design Files
The files in this bundle (`prototype/Budget Tracker.dc.html`) are an **HTML/React design reference**, built in a proprietary in-house prototyping format (a custom "Design Component" runtime — templated JSX-like markup + a logic class, not a standard framework). **Do not attempt to run or copy this file's markup/runtime directly.** Treat it purely as a working, interactive spec of layout, states, copy, and behavior. The task is to **recreate this design in the target codebase's existing stack** (React/Vue/etc., with its existing component library, state management, and routing) — or, if no frontend exists yet, choose a conventional modern stack (e.g. React + TypeScript + a charting lib) and build fresh.

A screenshot-annotated walkthrough is in `screenshots/` for visual reference (see below for whether these were included).

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy in this document are final and should be matched closely. Interaction patterns (modals, inline editing, hover tooltips, expand/collapse) are all intentional and should be preserved. The underlying sample data (member names, transaction amounts, categories) is placeholder/demo data — the real app should start with an empty state or an import flow (not built in this prototype).

## Global Layout & Design Tokens

### Colors
| Token | Hex | Usage |
|---|---|---|
| Navy (primary/dark) | `#12213d` | Header background, primary buttons, active pill backgrounds, net-row background |
| Navy hover/lighter | `#1a2c4d` | Logo tile background |
| Slate text (headings) | `#16213f` | Body text, headings |
| Slate secondary | `#3a4459` | Secondary text (row labels, member names) |
| Muted gray text | `#6b7686` | Labels, captions, KPI titles |
| Faint gray text | `#8a93a3` | Placeholder/empty-state text, axis labels |
| Border gray | `#d6dae1` | Card borders, table borders |
| Divider gray | `#e2e6eb` | Segmented-control track backgrounds, subtle borders |
| Panel gray | `#f4f5f7` | Table header background, chip backgrounds, group-row background in spreadsheet |
| App background | `#eef0f3` | Page background ("platinum/silver") |
| White | `#ffffff` | Card backgrounds |
| GitHub green (inflow) | `#2da44e` | Income amounts, positive net, income line/legend |
| GitHub red (outflow) | `#cf222e` | Expense amounts, negative net, expense line/legend |
| Net-row light green | `#8fd19e` | Net row text on navy background when positive |
| Net-row light red | `#ffb3ac` | Net row text on navy background when negative |

Category/bucket chart colors are a curated 12-color palette (see `GROUP_COLORS` in the logic — navy/slate/teal/purple/amber/etc. tones), user-customizable per bucket via a color picker (see Buckets section below). Members are auto-assigned from a 5-color palette (`MEMBER_COLORS`, blue-toned).

### Typography
- **Body/UI font:** IBM Plex Sans (400/500/600/700), loaded via Google Fonts.
- **Numeric/monospace font:** IBM Plex Mono (500/600) — used for ALL currency amounts, table figures, and hex/RGB picker inputs, to keep digits aligned.
- Base body text ~13–13.5px. Card titles 14px/600. Page section headers 16px/700. KPI values 26px/600 mono. Micro-labels (uppercase table headers, captions) 11–11.5px/600 with `letter-spacing: 0.4–0.5px`, `text-transform: uppercase`, color `#6b7686`.

### Spacing & Shape
- Card border-radius: 12px. Small controls (buttons, inputs, chips): 6–8px. Pills/segmented controls: 7–8px container, 6–7px inner buttons.
- Cards: `1px solid #d6dae1` border, no shadow (flat, data-dense aesthetic), `16–20px` padding.
- Page content max-width 1400px (Dashboard/Transactions) or 1100px (Settings), centered, `24px 28px 40px` outer padding.
- Grids use CSS Grid/Flexbox with explicit `gap` (12–20px) — never margin-based spacing.

### Currency & Date Formatting
- **Currency: Philippine Peso.** Format as `₱` + thousands-grouped integer (no decimals shown in this prototype), e.g. `₱3,145`. Signed variant for net/cashflow values: `+₱1,200` / `−₱450` (using a true minus sign `−`, not hyphen).
- **Dates: ISO 8601, `yyyy-mm-dd`** everywhere in custom-rendered text (list rows show `yyyy/mm/dd`). Native `<input type="date">` pickers unavoidably render in the browser's locale format — flag this as a known platform limitation, not a design intent; a real build may want a custom date input to guarantee ISO display.
- All times/dates are date-only in this prototype (no time-of-day data model).

## Data Model
```
Member    { id, name, color }
Category  { id, type: 'income'|'expense', group: string, name: string }  // group = bucket, name = sub-category
Transaction {
  id, date (ISO string), memberId, categoryId,
  type: 'income'|'expense', amount (number, always positive),
  description (string, optional), recurring (boolean)
}
```
- A **bucket** = a `group` value shared by one or more `Category` rows of the same `type`. E.g. group "Housing" (expense) contains sub-categories "Rent", "Utilities".
- **Recurring** transactions: when checked at creation with a start date, the prototype auto-generates 12 monthly instances (same day-of-month, one per month for a year) rather than modeling a true recurring-rule object. A production build should likely model this as a proper recurring rule (frequency, end condition) instead of pre-materializing instances, while preserving the "check a box, get monthly repeats" UX.
- Custom bucket chart colors are stored as a `{ [groupName]: hex }` override map, falling back to the palette-by-index.

## Screens / Views

### 1. Header (persistent, all tabs)
- Fixed/sticky top bar, navy (`#12213d`) background, `4px 28px` padding (thin bar), `28px` gap between sections, `box-shadow: 0 2px 8px rgba(0,0,0,0.15)`.
- Left: 48×48px rounded-8px logo tile (`#1a2c4d` bg) containing the product mark (42×42px, cropped tight to art bounds, PNG asset — see Assets), plus wordmark "Celia" (17px/600, `#f3f4f6`).
- Center-left: nav pills — Dashboard / Transactions / Settings. Active pill: white bg, navy text. Inactive: transparent bg, `#c3ccd6` text.
- Right: primary CTA button "+ Add Transaction" — white bg, navy text, 8px radius, opens the Add/Edit Transaction modal (see below).

### 2. Dashboard tab
Layout: vertical stack, `20px` gap, four zones:

**a. Controls row** (flex, space-between, wraps on narrow):
- Left: period-mode segmented control (Pay Period / Month / Year) + a period navigator (‹ prev / center label / next ›) in a bordered pill. Pay Period = a half-month (1st–15th, 16th–end); this is the primary budgeting cadence per user's pay schedule.
- Right: household member filter chips — "Household (All)" + one chip per member (active = filled with member's color; inactive = light gray `#e2e6eb`).

**b. KPI row** — 4 equal-width cards: Income, Expenses, Net, Savings Rate.
- Each: uppercase label (+ an "ⓘ ” info-icon hover tooltip on Savings Rate explaining the formula), large mono value (26px/600, green for income/positive net, red for expense/negative net, navy for savings rate), small gray sub-caption (period label or "Surplus"/"Deficit").
- **Net KPI shows a plain, unsigned amount** (no leading +/−) — the color and "Surplus"/"Deficit" caption alone convey direction. (This was an explicit revision — do not re-add a sign prefix.)
- Savings Rate formula: `(Net ÷ Income) × 100`, rounded to whole percent; if Income is 0, show 0%.

**c. Charts row 1** — two cards side by side (ratio 1.4fr / 1fr):
  - *Income vs. Expense Trend*: line chart (custom SVG, not a library), 560×180 viewBox, two lines (green=income, red=expense) sharing **one Y-scale** (critical: both series must share the same max/scale so visual crossing is meaningful — this was a bug fix in this project's history), circular hover markers on each data point showing a floating tooltip (period label + exact amount), x-axis period labels below, small square-marker legend (not dots — squares match the other chart's legend for consistency).
  - *Spending by Bucket*: donut chart (custom SVG rings via stroke-dasharray), 170×170px, one ring segment per expense group in the current period, sorted descending by amount. Center shows "Total" caption + mono total amount as an **HTML overlay positioned absolutely over the SVG** (not an SVG `<text>` element — nested dynamic text inside SVG `<text>` failed to render in this stack; use whatever your text-in-SVG approach is, just don't literally nest a templated string inside an SVG text node without testing it renders). Hover on ring segments shows a tooltip (group name, amount, %). Legend to the right: colored square swatch + group name + amount, compact rows (12px font, 4px gap).
  - Empty state: "No expenses this period." when the donut has no data.

**d. Charts row 2** — two more cards (same 1.4fr/1fr ratio):
  - *Cash Flow (Running Balance)*: area+line chart, cumulative sum of net (income − expense) across the trailing 6 periods (not just the current one), dashed zero-line, subtle navy-tinted area fill under the line, hover point tooltips. Has an "ⓘ" info icon with tooltip explaining what running balance means.
  - *Household Comparison*: grouped bar chart (plain divs, not SVG) — one pair of bars (income green / expense red) per household member for the current period, member name + net amount below each pair. This chart always reflects the full household regardless of the page's member-filter (a deliberate choice so you can always compare members even while filtered to one).

**e. Footer note**: dashed-border callout box, muted text: "Coming soon — forecasting projected balances from your recurring income and expenses." (Placeholder for an unbuilt future feature — keep as a visible roadmap signal, not a dead end.)

### 3. Transactions tab
Layout: controls stacked above one of two views (List / Spreadsheet), toggled by a segmented control.

**Shared controls row** (top): household scope chips (same chip pattern as Dashboard — "Household (All)" + per-member; this exact control is now shared/unified between filtering the List and scoping the Spreadsheet — a past revision explicitly removed a redundant second member-filter dropdown, don't reintroduce one) + a List/Spreadsheet view-mode segmented control on the right.

**3a. List view** (default):
- Secondary controls row (only shown in this view): search-by-description text input, a type filter dropdown (All types / Income / Expense), and a transaction-count caption on the right.
- Table-like list: header row (Date / Member / Bucket / Description / Amount / Recurring-indicator / spacer) then one row per transaction, grid-templated columns `100px 110px 170px 1fr 120px 70px 36px`.
- Each row: date (`yyyy/mm/dd`), member (colored dot + name), bucket (`Group / Subcategory`), description, amount (mono, green/red, `+`/`−` prefix), recurring glyph (↻) if applicable, and a small "×" delete button.
- **Rows are clickable** — clicking anywhere on a row (except the × button, which stops propagation) opens the same modal used for adding, pre-filled, in **edit mode** (see Modal below). This replaced an earlier separate "Grid" inline-editable view, which was removed as redundant once row-click-to-edit existed.
- Empty state: "No transactions match your filters."

**3b. Spreadsheet view** (pivot table):
- Its own controls row: period-mode segmented control (Pay Period / Month / Year) + prev/next navigator, analogous to the Dashboard's but with independent state (a separate "reference date" from the Dashboard's).
  - Pay Period mode → 1 data column (the single half-month).
  - Month mode → 2 columns (that month's two half-month periods).
  - Year mode → 24 columns (12 months × 2 periods each). Column headers are simple single-row labels like "Jan 1–15" / "Jan 16–31" (a deliberate simplification vs. a two-tier grouped header, to keep 24-column implementation tractable — flag if a two-tier month-group header is wanted later).
- Table: sticky first column (bucket/category name, `170px` min-width) and sticky header row, horizontally scrollable body.
  - Rows: one per **bucket** (group), bold, with an expand/collapse chevron (▸/▾) revealing indented **sub-category** rows underneath when expanded. Two sections — Income buckets first, then Expense buckets — each followed by a "Total Income" / "Total Expenses" subtotal row (tinted background `#e2e6eb`, colored green/red). A final **Net** row (navy background, light green/red text) sums Income − Expense per column.
  - Columns: one cell per time period showing that bucket/category's summed amount for the period, plus a **Row Total** column (sum across all shown periods) on the far right, and column totals via the subtotal/net rows.
  - **Editable cells**: only sub-category (leaf) cells, and only when there are 0 or 1 underlying transactions in that bucket+period+scope. Editing an empty cell creates a new transaction (dated to the period's start, assigned to the scoped member or the first household member if scope is "Household (All)"). Editing a cell with exactly one transaction updates that transaction's amount. Cells with 2+ transactions render as **read-only text** (not an input) since editing would be ambiguous — a caption below the table explains this and points users to List view to edit those individually. Group/subtotal/net rows are always read-only (computed rollups).
  - This view directly serves the user's original ask for an "Excel-like" pivot: rows = buckets (expandable to sub-categories), columns = time periods, values = household total / per-person depending on the scope chips above.

### 4. Settings tab (formerly "Buckets")
Two sections, each with a bold 16px section header + one-line gray description, separated by a `1px solid #d6dae1` horizontal rule.

**a. Buckets section**
- **"New Bucket Group" panel is positioned first** (above the bucket list) — text inputs for group name + first sub-category name, an Income/Expense type toggle, and a "Create Group" button.
- Below it: a responsive grid (`auto-fill, minmax(280px,1fr)`) of one card per bucket group:
  - Header row: a small clickable color swatch (14×14px rounded square) + group name (14px/600) + type label (uppercase, right-aligned, muted).
  - **Clicking the swatch** (not a separate button — this was an explicit simplification) opens a custom color-picker popover anchored below it: a saturation/value gradient square (drag to pick) + a hue slider strip (drag to pick) + hex/R/G/B numeric text inputs, all live-synced. Only expense-group swatches are clickable/customizable (income groups are fixed green, matching the KPI/chart convention). Clicking outside the popover (a full-screen invisible overlay) closes it.
  - Below: wrapped chips of sub-categories (name + small "×" delete), then a small inline "add sub-category" text input + Add button.

**b. Household section**
- Single card "Household Members": chips of existing members (colored dot + name + delete ×) plus an inline "new member name" input + "Add Member" button. Deleting a member resets any filter currently scoped to them back to "All".

### 5. Add/Edit Transaction Modal
- Triggered by the header's "+ Add Transaction" CTA (add mode, fresh blank-ish form) or by clicking a transaction row in List view (edit mode, pre-filled, title and submit button read "Edit Transaction", plus a red "Delete" text-button on the left of the footer).
- Centered overlay dialog, `rgba(18,33,61,0.45)` scrim (click-outside-to-close), white card, 14px radius, 24px padding, 440px wide (92vw max on small screens).
- Fields: Date + Member (side by side), Income/Expense type toggle (full-width segmented pill), Bucket (group) + Sub-category dropdowns (side by side, sub-category options filtered live by selected group/type), Description (full width), Amount + a "Recurring" checkbox (side by side).
- Validation: category and a positive numeric amount are required; inline red error text under the fields on failure.
- Footer: Delete (edit mode only, far left) — Cancel — primary submit button (label matches modal title).
- **Custom select-arrow implementation**: all `<select>` elements across the app use `appearance: none` plus a hand-drawn SVG chevron via `background-image` + explicit `background-position: right Npx center`. This was a deliberate fix — relying on native select padding to "push" the browser's built-in arrow does **not** work (the browser draws its arrow at a fixed inset regardless of padding); don't reintroduce plain `<select>` styling reliant on padding alone.

## Interactions & Behavior Summary
- Tab switching, period navigation (prev/‹ next›), and filter chip selection are all simple state swaps — no transitions/animations were used, keep it snappy/instant.
- Hover tooltips on all chart data points (trend lines, cash-flow points, donut segments) and the Savings-Rate/Cash-Flow info icons: implemented as a single global floating tooltip `<div>` (fixed-positioned at the cursor, offset +12px/+12px) shown/hidden/moved via mouseenter/mousemove/mouseleave handlers — not native browser `title` tooltips (those proved unreliable/inconsistent for this use case; a real build can use any tooltip primitive that reliably tracks the cursor and shows rich text).
- No drag-and-drop, no animations/transitions beyond instant show/hide.
- No persistence beyond in-memory React state in this prototype (see Data below) — a production build needs real persistence (see Assets/Data note).

## State Management (prototype-level; re-derive properly in production)
Prototype state (single component, for reference only — not a schema to copy 1:1):
- `members[]`, `categories[]`, `transactions[]` — the core data, currently seeded with 6 months of demo data for 2 members ("Alex", "Jordan").
- `activeTab`, `memberFilter` (Dashboard scope), `periodMode` + `refDate` (Dashboard period nav).
- `txScope` (shared List/Spreadsheet member scope), `searchQuery`, `txTypeFilter`, `txViewMode` ('list' | 'pivot').
- `pivotMode` + `pivotRefDate` (Spreadsheet's own period nav, independent of Dashboard's), `expandedGroups` (map of which buckets are expanded in Spreadsheet view).
- `showAddModal`, `editingId` (null = add mode, else edit mode), `form` (the modal's field values), `formError`.
- `customGroupColors` (map of group name → hex override), `colorPickerOpenFor` (which bucket's picker popover is open) + `pickerH/S/V` (current picker state) — the picker commits directly to `customGroupColors` on every drag/input change (no separate "confirm" step).
- `tooltip` (the single global floating tooltip's current text/position, or null).

For a real backend, model `Member`, `Category` (bucket/sub-category), and `Transaction` as above, plus persist `customGroupColors` per category-group and consider a real recurring-transaction rule model instead of pre-generated instances.

## Assets
- `assets/celia-logo.png` — the product mark: a white line-art circular medallion (an 8-spoke wheel/mandala motif with a diamond center and compass-point accents at N/S/E/W), transparent background, cropped tight to the artwork's bounding box (538×525px source). Rendered at 42×42px inside a 48×48px navy (`#1a2c4d`) rounded tile in the header. Source it as a proper vector (SVG) in production if possible for crisp scaling; treat the current PNG as a placeholder mark, not a final logo file, since it originated from an AI image generation. Get sign-off on it as a real brand asset before shipping.

## Files
- `prototype/Budget Tracker.dc.html` — the full interactive prototype (reference only, see "About the Design Files" above).
- `assets/celia-logo.png` — logo asset described above.
