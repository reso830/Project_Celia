# Project conventions

## Charts
- Axis tick labels (months, categories) always sit OUTSIDE the plot area — below the x-axis line, never inside the plotted region. Applies to wireframes and hi-fi.
- Legends state the encoding with literal swatches (filled square = bars, dashed rule = budget line); stacked vertically.

## Money tracker product decisions
- Currency: PHP. Multi-currency / live forex is a later, secondary feature.
- Categories are two levels: category → item. Entries attach to an item.
- Entry owner is optional; default owner is "Household". Household view aggregates everything.
- Filters are per-screen, not global.
- Three top-level umbrellas: Income, Expenses, Savings. Savings is NOT an expense category.
- Savings is held in buckets: goal (target amount + date), open-ended fund, sinking fund (annual cost ÷ months, editable). Debt payoff stays in Expenses — the installment is an expense, the balance is a forecast input.
- One bucket is the default: unallocated surplus sweeps into it and it always counts toward the buffer. Other buckets can be nominated to count; goal and sinking buckets don't by default.
- Savings buffer = sum of counted buckets. Runway = buffer ÷ monthly expenses.
- Monthly maths: net = income − expenses − savings funded; what remains is "unallocated".
- Withdrawing from a bucket is not an expense — only the bucket balance drops.
- Under-funding a bucket is amber, never red.
- Models are budget templates: one amount per category, repeating monthly. Models budget savings per bucket too.
- The dashboard scores each month against the model that was active in that month — no model picker on the dashboard. Cross-model comparison lives on the forecast screen only.
- Dashboard KPI: "Savings buffer" shows the amount first, with "covers N months of expenses" beneath. On the forecast screen, runway stays expressed in months for scenario comparison.
- Each category owns a fixed colour, set in the category manager and reused in every chart, swatch and chip. Category colour is identity; traffic-light green/amber/red is status — never conflate the two (swatches are squares, status dots are circles).
- Chart axes: surplus up, deficit down. Δ is favourable-positive — for expenses Δ = budget − actual (underspending is +, green); for income and savings Δ = actual − budget (a shortfall is −, red). Positive is always the good direction, in every umbrella.
- Never use the words "over budget" / "under budget" in UI copy — they read both ways ("we overspent" vs "the budget exceeds the actual"). Say overspent / underspent, or state the amounts.
- Overspend signalling: per-category traffic light, pace indicator, rollover of unspent budget.
- Forecast outputs: months of runway, monthly surplus/deficit, affordability verdict chip.
- Recurring entries: out of scope for now.
