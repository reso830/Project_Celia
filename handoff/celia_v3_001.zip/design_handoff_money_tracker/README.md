# Design Handoff: Household Money Tracker

## Overview
A desktop web app for one household to track **income, expenses and savings**. Every month is scored against a budget template (a **model**), savings sit in **buckets**, and the **forecaster** compares what-if scenarios, e.g. "what if we buy a car", against the baseline. Everything rolls up to the household by default and can be filtered by member.

The design has 7 screens and 1 modal (Add / Edit entry). The Merge, Archive and Move-item modals exist as wireframes only.

## About the design files
The files in `reference/` are **design references built in HTML**. They are prototypes that show the intended look and behaviour, **not production code to copy**. Recreate them in the target codebase using its framework, component library and patterns. If there is no codebase yet, pick a suitable stack. The prototype's in-memory state and inline styles are prototyping shortcuts, not architecture to reuse.

- **`reference/Money Tracker Hi-Fi.dc.html`** is the interactive hi-fi prototype and the visual source of truth. Open it in a browser with `support.js` beside it; it needs internet access for Google Fonts. The left rail switches screens, and every number is computed live from the seed data.
- **`reference/Money Tracker Wireframes.dc.html`** holds the lo-fi wireframes. Use it only where the hi-fi has no design yet (Merge, Archive and Move-item modals). Where the two differ, the hi-fi wins.
- **`reference/product-decisions.md`** is the product rules log agreed during design. These are binding.
- **`data/seed.json`** is the demo data behind every figure in the prototype: categories, colours, items, 12 months of actuals, buckets, models and scenarios.

## Fidelity
**High fidelity** for the 7 screens and the entry modal: final colours, type, spacing, radii, copy and interactions. Recreate them precisely. The owner will refine visuals later, so put every value below behind tokens and don't hard-code them.
**Low fidelity** for the Merge, Archive and Move modals. Take the structure from the wireframes and the styling from the hi-fi tokens.

---

## Global layout

- **Shell:** full-height flex row on page background `#eceded`.
  - **Icon rail:** 72px wide, background `#dcdfdf`, right border `1px #cbcfcf`, vertical padding 18px, 6px gap.
    - Logo tile: 34×34, radius 10, `#2f7d78`, white "C" in Sora 700 15px, 14px below it.
    - Nav items: 44×40, radius 11, icon 16px. Inactive: icon `#6f7679`, hover background `#e8eaea`. Active: background `#fff`, icon `#2f7d78`. Each has a tooltip with its label.
    - Order: Dashboard ◱, Entries ☰, Categories ⌗, Savings buckets ◎, Budget models ≣, Forecaster ⤳, Household ⚭. These are Unicode placeholders; map them to the codebase's icon set.
  - **Content column:** flex 1, `min-width:0`, padding ~26px 30px 40px. Every screen renders inside it.
- **Page header** (every screen): one row, wrapping, space-between.
  - Left: page title, Sora 600 27px, letter-spacing −0.02em. **No subtitles on any page.**
  - Right, per screen: filter dropdowns, month picker, primary CTA.
  - **Month picker:** white segmented control, border `1px #d5d8d8`, radius 10. Parts are ◀ / "September 2026" (500, 13.5px) / ▶, with 1px dividers between them.
  - **Member dropdown** (Dashboard, Entries): "Household ▾" with options Household, Ana, Miguel.
  - **Category dropdown** (Dashboard, Entries only): "All categories ▾" with options All categories plus each category. Hidden on the Categories screen.
  - **Range dropdown** (Dashboard): 6 mo or 12 mo. Same height as the member dropdown.
  - **Primary CTA** "+ Add entry": background `#14181a`-family dark, white text, radius 10, padding 11×18, 13.5px/500.
  - Filters are **per screen**. They don't carry over between screens.
- **Responsive:** desktop-first; target 1280–1440 wide. Grids use `minmax(0,…)` tracks so they shrink rather than overflow. Nothing should scroll horizontally at ≥1100px.

## Screens

### 1. Dashboard
The question it answers: *where does this month stand against the active model, and how much cushion do we have?* It always scores against the model that was **active in that month**. There is no model picker here.

**Row 1: KPIs** (grid `minmax(200px,35%) 1fr`, gap 14)
- **Savings buffer (hero):** dark card `#3a4145`, radius 14, padding 20.
  - Label "SAVINGS BUFFER": 11px, letter-spacing .07em, `#b7bec0`, `nowrap`.
  - Value, e.g. ₱573,500: JetBrains Mono 700 38px, white, `nowrap`.
  - Beneath: "7.3 months runway", bold but clearly subordinate to the value.
  - Right: sparkline of the buffer over the visible months, vertically centred in the card. Thick stroke, no area fill. It shrinks before the text does.
- **Four secondary KPIs** in a 2×2 grid of white cards (border `#d5d8d8`, radius 14): **INCOME**, **EXPENSES**, **SAVINGS**, **UNALLOCATED**.
  - Label: 11px caps, `nowrap`.
  - Value: Mono 700 22px. Unallocated is teal `#2f7d78` when ≥0 and red `#b0533c` when negative, signed (+₱26,900).
  - Each card has a sparkline on its right, vertically centred, no fill. Unallocated's is teal; the others are `#5c6467`.

**Row 2** (grid `minmax(240px,35%) 1fr`)
- **Burn rate gauge card.**
  - Arc sweeps 270° on the unit circle, from **225° (0%) clockwise to −45° (150%)**.
  - Outer thin band (stroke 4–5): green `#3f7d5c` 0–85%, amber `#d3a13f` 85–115%, red `#b0533c` 115–150%, with **white gaps between bands**.
  - Inner thick value arc (stroke ~16–18): filled from 0 to the value in the status colour. The unfilled track is transparent. There's a small white gap between the inner arc and the outer band. No needle.
  - Thin grey callout ticks (`#c8c5bd`) with labels at 0%, 100% and 150%.
  - Centre: the percentage (Mono 700 ~32px) with "Sep 2026" beneath it, in the true centre of the gauge.
  - Status colour: <85 green, 85–115 amber, >115 red.
- **Actual vs budget:** combined bar + line chart for the last 6 or 12 months (range dropdown in the header).
  - Bars show actual expense. The current month is teal `#2f7d78`, overspent months `#e8d3cb`, others `#d3d7d8`. Radius 6 on top corners.
  - A dashed budget line (`2px dashed #3a4145`) marks the active model's budget.
  - Month labels (3-letter: Oct, Nov…) sit **below the x-axis, outside the plot**. The current month label is ink and 500 weight.
  - Legend below, stacked, with literal swatches: filled square = "actual expense", dashed rule = "budget · Baseline 2026".
  - Clicking a bar selects that month.

**Row 3** (grid `repeat(2, minmax(0,1fr))`, i.e. 50/50)
- **Categories table.** Title "Categories", with "↺ unspent rolls over" on the right.
  - Grid `1.8fr 1fr 0.9fr 0.75fr 0.6fr`, gap 8.
  - Columns: CATEGORY (colour square swatch 11px, radius 3, then name) · SPENT (Mono 12px, with "of 20,000" in 10.5px `#5c6467` beneath) · USED (7px progress bar, radius 4, in status colour) · Δ (signed, green if positive, red if negative) · ↺ (rollover amount in green, or "—").
  - A Total row sits at the bottom on background `#f4f5f5`.
  - **Rows are not clickable.** Status is shown by the inline bar only; there are no traffic-light dots.
- **Expense per member.** One row per member (Household, Ana, Miguel), showing name, amount and a horizontal stacked bar split by category colour. A horizontal legend of category swatches sits below.

**Row 4** (auto-fit grid, `minmax(270px,1fr)`)
- **Goal card:** ring (conic, amber until 100% then green) with % in the centre, the goal name "Car down payment", "111,500 / 180,000", and a note "At ₱5,000/mo → N months to target".
- **Upcoming commitments:** list of name · due date (muted) and amount (Mono), with 1px dividers.
- **Empty state:** with no goal bucket, the goal card isn't shown.

### 2. Entries
- **Header:** Member and Category dropdowns, month picker, + Add entry.
- **Chip row** of pills (white, border, radius 20, 13px): Entries N · Expense ₱ · Income ₱ · Avg / entry ₱, plus a search input "Search notes and items…". Chips recompute instantly when filters change.
- **Table** (white card, radius 14). Grid `78px minmax(0,34%) 1fr 0.8fr 100px 58px`:
  - Columns: DATE (sortable) · ITEM · CATEGORY (swatch + name) · OWNER · AMOUNT (right-aligned Mono; income positive in green) · actions.
  - **DATE header** toggles the sort: ▼ newest first (default), ▲ oldest first. The chevron is 8px teal.
  - **Row actions:** ✎ edit and ✕ delete, each 22×22 with radius 6. Edit hovers to `#e4efee` background with `#26686a` icon; delete hovers to a `#b0533c` fill with white icon. Edit opens the entry modal pre-filled. Delete removes the row and shows the toast "Entry deleted".
  - No footer row.
  - Empty state: "No entries match these filters."

### 3. Add / Edit entry modal
- **Overlay:** `rgba(20,24,26,.42)`; clicking it closes the modal.
- **Card:** 520px wide (max `100vw − 40px`), white, radius 16, padding 24, `max-height:88vh`, scrolls.
- **Title:** "Add entry" or "Edit entry", 20px/600, with ✕ close. 18px below.
- **Type toggle:** Expense | Income, segmented on `#e0e2e2`, radius 9. 20px below.
- **Rows** are 18px apart. Labels are 11.5px caps, letter-spacing .06em, `#5c6467`, 5px above the control. Every control is **42px tall**, border `1px #d5d8d8`, radius 9.
  1. AMOUNT (PHP): Mono 16px text input · DATE: custom dropdown showing "19 Sep 2026 ▾". It opens a calendar popover **directly under the field** at the field's width: ◀ Month YYYY ▶, a Monday-first grid, 32px day cells, selected day on `#26686a` with white text.
  2. CATEGORY: custom dropdown with swatch and name · ITEM: custom dropdown. The popover sits 4px under the field and matches its width, max-height 240 with scrolling; options have 8×10 padding, radius 7, and the selected option is `#e4efee`/`#26686a`. Only categories of the chosen type are listed, and **changing category resets item to that category's first item**.
  3. OWNER: segmented Household | Ana | Miguel, **default Household**. Helper text: "Optional — stays with the household unless you pick a member."
  4. NOTE: multi-line textarea, 3 rows, min-height 84, resizes vertically, placeholder "Optional".
- **Preview strip** (`#f4f5f5`): "Groceries after save: 18,400 / 20,000".
- **Footer:** Cancel · Save & add another (hidden in edit mode) · Save.
- **Popover behaviour:** only one popover is open at a time. It closes on selection, on clicking elsewhere in the modal, or when the modal closes. Don't use native `<select>` or `<input type=date>`; their pop-ups misplace under zoom.
- **Validation:** amount must be > 0. When it isn't, the amount border turns `#b0533c` on `#fdf6f3`, the preview reads "Enter an amount above zero.", and **Save is disabled**: muted `#5c6467` text on `#f4f5f5` with border `#d5d8d8`. Don't use white-on-grey.
- **On save:** toast "₱3,240 added to Groceries" (or "Entry updated" when editing). "Save & add another" keeps the modal open and clears amount and note.

### 4. Categories & items
- **Two-pane grid:**
  - **Left list** (max 340px): collapsible groups INCOME and EXPENSES, each with an item count on the right. Rows show a swatch, the name and "N items". A selected row is highlighted.
    - Hovering a name shows ✎ to rename in place.
    - Clicking the swatch opens a colour picker. **The category colour is set here and reused in every chart, swatch and chip.**
    - Archived categories stay in their group with a marker.
  - **Right detail:** swatch, name (20px/600), Merge and Archive buttons. Below that, a summary panel (`#f4f5f5`) with "Sep 2026 spend" ₱ (Mono 24px), "of ₱ budgeted · N entries" and a small burn gauge for this category (same spec as the dashboard gauge, ~170px). Then an items table (ITEM · ENTRIES · SEP) where each row has a Move icon to move the item to another category.

### 5. Savings buckets
- **KPI row:**
  - HELD IN BUCKETS ("4 buckets")
  - SAVINGS BUFFER ("counted buckets only")
  - RUNWAY ("buffer ÷ monthly expenses")
  - FUNDED SEP ("₱X short", in amber, or "on plan")
- **Bucket cards** (auto-fit, 300px min): name + badge (DEFAULT on the default bucket), type line (e.g. "Goal · Feb 2027", "Sinking · Mar 2027", "Open-ended"), balance (Mono 19px), progress bar toward the target, a "Funded Sep ₱" line, and a **buffer** toggle switch saying whether the bucket counts toward the buffer.
- **Types:** goal (target + date) · open-ended fund · sinking fund (annual cost ÷ months, editable).
- The default bucket ("Cash buffer") always counts, and its toggle is locked. Unallocated surplus sweeps into it.

### 6. Budget models
- **Grid `minmax(200px,25%) 1fr`.**
  - **Left:** model cards showing name, badge ACTIVE, and two summary lines. The selected card is highlighted. A "+ New model" button sits beneath.
  - **Right detail:**
    - **Header:** model name, then Duplicate · **Make active** · **Delete**.
      - Make active is teal and filled. On the model that's already active it becomes "Active", disabled (muted on `#f4f5f5`).
      - Delete has a red outline (`#dcc3bc` border, `#b0533c` text) and fills red with white text on hover.
    - **"Where the income goes":** a 100% stacked bar, 28px tall, radius 6, splitting planned income into Expenses `#8c8378` · Savings `#2f7d78` · Unallocated `#c3cac9`. **Percentages sit inside the segments** (white on dark, ink on pale). The legend below has names only; the ₱ amount shows on hover. "₱119,500 planned income" is on the right of the title.
    - **Chart row** (grid `35fr 65fr`):
      - **Expense breakdown:** donut, 176px ring with a 108px hole, sliced by category colour, no centre label.
      - **Budget vs actual (Δ):** a diverging bar per category around a zero line at the vertical centre. Bars go up for surplus and down for deficit, in the category's colour. Rotated caps labels "SURPLUS" / "DEFICIT" (10.5px, letter-spacing .08em, 500) sit centred in their halves on the left. Category labels (first 4 letters) sit **in one row beneath the whole plot**. Bars scale to the panel height.
    - **Table** (`45% 1fr 1fr 0.9fr`): CATEGORY · BUDGET / MO · 3-MO ACTUAL · Δ.
      - Three collapsible umbrella groups in the order **Income, Expenses, Savings**.
      - Each group is **one bordered block** (border `#e2e4e4`, radius 9). Its header bar (background `#f4f5f5`, caret, label) carries the group totals, so they stay visible when the group is collapsed.
      - Budget cells are editable inputs.
      - Footer row: Unallocated (Mono 13px, `nowrap`, teal when positive, red when negative).

### 7. Forecaster
- **Scenario chips:** Baseline plus up to 3 scenarios (A, B, C), each with its own colour and dash style, and "+ scenario". The selected chip is highlighted. ✕ / 🗑 appears on hover only.
- **Grid `minmax(260px,320px) 1fr`.**
  - **Left, inputs:**
    - **What changes:** the list of events for the selected scenario, e.g. Car · financed purchase · −18,430/mo. Event types include one-off, financed purchase or installment, recurring, seasonal and sinking fund. Click an event to edit it; "+ add event" adds one. Footer: "Net monthly impact" in red, e.g. −₱26,430.
    - **Nudge the budget:** per-category and per-bucket −/+ steppers in steps of 500, grouped by umbrella (EXPENSES, SAVINGS). Each shows its value and a small bar.
  - **Right, outputs** for the selected scenario:
    - Scenario name.
    - Three equal KPI cards on one row (`repeat(3,minmax(0,1fr))`), in this order:
      - **VERDICT:** a tinted chip card. Comfortable is green (`#2c6647` on `#f1f7f3`), Tight but doable is amber (`#8a6516` on `#fdf9f0`), Risky buffer is red (`#8a3b28` on `#fdf6f3`).
      - **RUNWAY:** "N mo", with "from X mo" beneath.
      - **MONTHLY UNALLOCATED:** signed, with "₱X drawn from the buffer" or "buffer untouched" beneath.
    - **24-month outlook:** bars for baseline unallocated plus a line per scenario.
      - The y-domain includes negatives, and a zero rule sits at the true zero, so a deficit plots **below** the axis.
      - A purchase-month marker is drawn.
      - Legend below, horizontal: baseline unallocated (square) and Scenario A, B, C (line swatches with their dash styles).
      - Axis labels sit below the axis.
    - **Scenarios side by side:** a table (grid `1.2fr repeat(4,1fr)`) comparing monthly expense, monthly unallocated, runway and verdict, with the note "runway = buffer ÷ monthly expense". Export sits at the top right of the screen.

### 8. Household
- **Header:** month picker, then "+ Add member".
- **Members table** (`0.8fr 2.2fr 110px 64px`), with a member count at top left.
  - Columns: member (initial avatar, "Ana Cruz", ✎ rename on hover) · INCOME VS. OUTGOING · KEEPS · Remove.
  - The INCOME VS. OUTGOING cell has two horizontal bars. Income is `#3a4145`. Outgoing is split into own expenses `#8c8378` and household share `#cfd3d3`. The numbers sit **left of** the bars so they're never clipped.
  - KEEPS is income − own − share, signed; green if ≥0, red if negative.
  - Remove is red text; on hover it fills red with white text.
  - No roles or role management.
- **Below** (grid `65fr 35fr`):
  - **Expense per member:** stacked monthly bars (Household, Ana, Miguel) with month labels below the axis and a legend.
  - **Defaults:** New entries owned by Household · Currency PHP · Active model Baseline 2026.

### 9. Merge, Archive and Move modals (wireframe fidelity, see the wireframes file)
- **Merge category:** pick a target category. Items and entries move across, and the source is removed.
- **Archive category:** the category is hidden from pickers but kept for history; archived categories stay listed with a marker.
- **Move item:** pick a new category for an item. Its entries follow it.

---

## Interactions & behaviour
- Changing month, member or category updates every number, chip and chart on that screen at once. No apply button.
- A toast (dark `#14181a`, white 13px, radius 10) appears bottom-centre for 2.2s after add, edit or delete.
- **Hover states:** nav tiles `#e8eaea`, secondary buttons `#f4f5f5`, destructive buttons fill red, edit icons teal-tinted.
- **Disabled controls** use muted ink on a light fill with a border, never low-contrast white on grey. Text contrast must be ≥4.5:1.
- There are **no drop shadows** anywhere. Separation comes from 1px borders only.

## Behaviour rules (from product decisions; binding)
- **Umbrellas:** Income, Expenses, Savings. Savings is *not* an expense. Withdrawing from a bucket is not an expense either; only the bucket balance drops.
- **Categories** have two levels: category → item. Entries attach to an item.
- **Owner** is optional and defaults to "Household". The household view aggregates everything.
- **Monthly maths:** unallocated = income − expenses − savings funded. Unallocated surplus sweeps into the default bucket.
- **Buffer and runway:** savings buffer = sum of counted buckets. Runway = buffer ÷ monthly expenses. The dashboard shows the amount first and runway in months beneath; the forecaster expresses runway in months.
- **Δ is favourable-positive everywhere:** expenses Δ = budget − actual; income and savings Δ = actual − budget. Charts plot surplus up and deficit down.
- **Status thresholds:** <85% green, 85–115% amber, >115% red. Under-funding a bucket is **amber, never red**.
- **Forecast verdict:** if monthly unallocated < 0, the verdict is capped at amber (Tight but doable) when runway ≥6 mo, otherwise red. With unallocated ≥0, runway ≥6 is Comfortable, ≥3 is Tight but doable, and below that is Risky buffer.
- **Colour roles:** category colour is identity (square swatches); green, amber and red are status (circles and bars). Never conflate the two.
- **Copy:** never say "over budget" or "under budget". Say overspent or underspent, or state the amounts.
- **Out of scope for now:** recurring entries, multi-currency and live forex, bank import, custom month start, a model-suggestion column, and buckets as a funding source in forecasts.

## State (what the UI needs)
- **Per screen:** selected month, member, category filter, and range (6 or 12).
- **Entries:** search text, sort direction.
- **Entry modal:** open flag, edit-entry id, form (type, amount, date, category, item, owner, note), open popover (date, category, item or none), calendar view month.
- **Models:** selected model, expanded groups.
- **Forecaster:** selected scenario, selected event.
- **Data:** entries, categories (+ colour, items), buckets, models (budget per category and savings per bucket, active flag), scenarios (events, nudges, start month, buffer draw).

## Design tokens
**Colour**

| Role | Hex |
|---|---|
| Page background | `#eceded` |
| Rail | `#dcdfdf` (border `#cbcfcf`) |
| Surface | `#ffffff` |
| Subtle surface | `#f4f5f5` |
| Segmented-control track | `#e0e2e2` |
| Border | `#d5d8d8` |
| Border, subtle | `#e2e4e4` |
| Row divider | `#eaecec` |
| Ink | `#14181a` |
| Ink 2 | `#3c4346` |
| Muted | `#5c6467` |
| Muted on dark | `#b7bec0` |
| Hero card | `#3a4145` |
| Accent (teal) | `#2f7d78` (dark `#26686a`, tint `#e4efee`) |
| Status green | `#3f7d5c` |
| Status amber | `#c9992f` (gauge band `#d3a13f`, text `#b9822c`) |
| Status red | `#b0533c` (tint `#fdf6f3`, border `#dcc3bc`) |
| Umbrella: Expenses | `#8c8378` |
| Umbrella: Unallocated | `#c3cac9` |
| Scenario B / C | `#7c6f9a` / `#a17c3f` |

**Category colours** (identity) are in `data/seed.json`: Rent `#7d8ba8`, Groceries `#7f9b6e`, Utilities `#c2a24a`, Transport `#6f9aa5`, Childcare `#a98bb0`, Dining out `#a5714f`, Health `#c98f9b`, Salary `#5f8a7d`, Freelance `#8a8f6e`.

**Typography**
- UI font: **Sora** 400/500/600/700.
- Figures: **JetBrains Mono** 400/500/700. Every monetary figure uses Mono.
- Scale:
  - Page title 27/600
  - Card title 15.5/600
  - Modal title 20/600
  - Body 13.5
  - Secondary 12.5
  - Caps labels 11–11.5, letter-spacing .06–.07em, weight 500
  - Hero figure Mono 38/700
  - KPI figure Mono 22/700
  - Table figures Mono 12

**Spacing:** 4-based. Card padding 16–20. Grid gaps 14 (cards) and 8–10 (table columns). Modal row gap 18.

**Radius:** card 14, modal 16, input and button 9–10, pill 20, popover 10, option 7, swatch 3, bars 4–6.

**Shadows:** none.

**Formatting:** currency is PHP, "₱119,500" (en-US grouping, integers). Signs use a true minus "−", and deltas carry "+", "−" or "±". Months are 3-letter (Sep); in headers, "Sep 2026" or "September 2026".

## Assets
There are no images. Icons are Unicode placeholders; map them to the codebase's icon library:
- dashboard ◱, entries ☰, categories ⌗, buckets ◎, models ≣, forecast ⤳, household ⚭
- edit ✎, delete ✕, dropdown ▾, prev / next ◀▶, rollover ↺

Fonts come from Google Fonts (Sora, JetBrains Mono).

## Files
```
design_handoff_money_tracker/
├── README.md                              ← this document
├── data/seed.json                         ← demo data behind every figure
└── reference/
    ├── Money Tracker Hi-Fi.dc.html        ← interactive hi-fi prototype (source of truth)
    ├── Money Tracker Wireframes.dc.html   ← lo-fi wireframes (Merge / Archive / Move modals)
    ├── support.js                         ← runtime needed to open the .dc.html files
    └── product-decisions.md               ← binding product rules from the design phase
```
